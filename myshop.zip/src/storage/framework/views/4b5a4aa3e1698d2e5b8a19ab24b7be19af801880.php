<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
   <?php $__env->slot('header', null, []); ?> 
      <?php if(auth()->guard()->check()): ?>
        <div class="flex justify-between items-center">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                商品一覧
            </h2>
            <a href="<?php echo e(route('products.create')); ?>" class="px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700">
                ＋ 新規登録
            </a>
        </div>
      <?php else: ?>
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            商品一覧
        </h2>
      <?php endif; ?>
   <?php $__env->endSlot(); ?>

  <div class="py-12">
      <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">

          <!-- 検索フォーム -->
          <form method="GET" action="<?php echo e(route('products.index')); ?>" class="mb-6 flex">
              <input type="text" name="keyword" value="<?php echo e(request('keyword')); ?>"
                  placeholder="商品名で検索..."
                  class="w-full border rounded-l p-2 focus:ring-2 focus:ring-indigo-500 focus:outline-none">
              <button type="submit" class="px-4 bg-indigo-600 text-white rounded-r hover:bg-indigo-700">
                  検索
              </button>
          </form>

          <!-- 商品一覧（カードグリッド） -->
          <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
              <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                  <div class="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition">
                      <img src="<?php echo e($product->image_path); ?>" alt="<?php echo e($product->name); ?>" class="w-full h-48 object-cover">


                      <div class="p-4">
                          <h3 class="font-bold text-lg truncate"><?php echo e($product->name); ?></h3>
                          <p class="text-gray-600 text-sm mb-2 truncate"><?php echo e($product->description); ?></p>
                          <p class="font-semibold text-indigo-600 mb-2"><?php echo e(number_format($product->price)); ?> 円</p>

                          <div class="flex justify-between items-center">
                              <a href="<?php echo e(route('products.show', $product)); ?>" class="text-blue-600 hover:underline">詳細</a>
                              <?php if(auth()->guard()->check()): ?>
                                  <div class="flex gap-2">
                                      <a href="<?php echo e(route('products.edit', $product)); ?>" class="text-green-600 hover:underline">編集</a>
                                      <form action="<?php echo e(route('products.destroy', $product)); ?>" method="POST" onsubmit="return confirm('削除しますか？');">
                                          <?php echo csrf_field(); ?>
                                          <?php echo method_field('DELETE'); ?>
                                          <button class="text-red-600 hover:underline">削除</button>
                                      </form>
                                  </div>
                              <?php endif; ?>
                          </div>
                      </div>
                  </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                  <p class="text-gray-500">商品が登録されていません。</p>
              <?php endif; ?>
          </div>
      </div>
  </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>

<?php /**PATH /var/www/src/resources/views/products/index.blade.php ENDPATH**/ ?>